# Update: reactivation fix, restaurant data tools, payments, ingredient list

Copy each file to the same path in the matching repo. Nothing to run in the database:
the three SQL files in database/ are ALREADY applied to your live Supabase project. They are
here only so your git history matches (put them in the restaurant repo's supabase/migrations,
numbered after 0025). Do not run them again.

## super-admin-repo/  (osamamalikawan/restropro-superAdmin)
- src/lib/renewal.ts                                   NEW
- src/app/super-admin/actions.ts                       changed
- src/app/super-admin/(console)/sidebar.tsx            changed (adds Ingredients)
- src/app/super-admin/(console)/subscriptions/actions.ts   changed
- src/app/super-admin/(console)/restaurants/restaurants-client.tsx   changed
- src/app/super-admin/(console)/restaurants/profile-modal.tsx        NEW
- src/app/super-admin/(console)/ingredients/{actions.ts,page.tsx,ingredients-client.tsx}  NEW

## restaurant-repo/  (osamamalikawan/restropro)
- app/api/ingredients/route.ts                         NEW
- app/(restaurant)/inventory/inventory-client.tsx      changed (Import ingredients button)

## Why reactivation failed
1. The Reactivate button only appeared for Suspended restaurants, never Terminated or Expired.
2. Even when it ran, it only flipped restaurants.status. Staff login also checks the
   subscription, and the nightly sweep puts a lapsed restaurant straight back to Expired.
3. Extending a lapsed subscription added time to the OLD end date (a date months in the past)
   and never un-expired the restaurant.
Now: Reactivate works for suspended, terminated and expired. If the subscription is cancelled
or past its grace period, a fresh period starts today (30 or 365 days by billing cycle). A
still-valid subscription is left alone. Extending or saving a future end date on the
Subscriptions page now counts from today when lapsed and brings an Expired restaurant back.
Suspended and terminated restaurants still need an explicit Reactivate.

## Bug fixed along the way
The Super Admin repo had its own sha256 hashPin in actions.ts. The restaurant app checks PINs
with bcrypt, so any restaurant onboarded from Super Admin would never accept its admin PIN.
It now uses src/lib/auth/pin.ts (bcrypt). A restaurant you already onboarded that way and
have not approved yet needs to be deleted and onboarded again (or its PIN reset).

## Restaurant profile (Restaurants > View)
- Last activity (latest of sales, shift clock-in, attendance, staff actions, expenses)
- Employees total and active, orders, and a live row count next to every delete option
- Record payment: amount, method, date, reference, optional "extend subscription by one period"
- Payment history. Stored in the new tenant_payments table, which no reset ever touches.
- Data tools: tick what to delete (sales, accounts, customers, menu, inventory, suppliers,
  expenses, shifts and attendance, tables and delivery areas, other employees), or Reset
  everything (you must type the restaurant name). Runs as one database transaction, so it
  either fully applies or not at all.
- Always kept: main admin (earliest admin employee), the restaurant and subscription, settings,
  payment methods, roles, devices, audit log, payment records. Deleting the menu is refused
  unless sales history is deleted too, because past orders reference those items.

## Ingredients
- New table ingredients with a category column, loaded with your 108 items.
- Super Admin > Ingredients: search, filter by category, add, edit, hide, delete.
- Restaurant Inventory > Import ingredients: search, filter by category, tick items, "Add
  selected" or "Add all new". Names already in inventory are skipped (case-insensitive), items
  arrive with 0 stock and 0 cost.

## Things I had to decide, please check
- Categories are my grouping (Meat & Poultry, Sauces & Condiments, Spices & Masala, and so on).
  Edit any of them in Super Admin > Ingredients.
- Names are exactly as in your file, typos included (Sauceges, Galic Sauce, Jelepeno, Eka...).
  Fix them from the same page.
- unit_type 0/1/2 and the stock/price numbers were not carried over. The numbers were one
  restaurant's own data, and I do not know what the unit codes mean. The raw code is stored in
  ingredients.legacy_unit_type, so once you tell me the meaning it is one UPDATE.
- "Tenant payment record" is built as payments a restaurant makes to the platform. If you
  meant something else, tell me.

## Still open from before
public.super_admins still has Row Level Security off, so anyone holding your public key can add
themselves as a super admin. Run this in the Supabase SQL editor:
  alter table public.super_admins enable row level security;
  create policy "read own row" on public.super_admins for select using (auth.uid() = user_id);
